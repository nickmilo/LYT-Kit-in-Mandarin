- metadata:
	- 标签: #source/book📚
	- 日期: 1844 (published); 2014 (read)
	- 人物: [[大仲马(Alexandre Dumas)]]
%%	- url: [wiki](https://zh.wikipedia.org/wiki/%E5%9F%BA%E5%BA%A6%E5%B1%B1%E6%81%A9%E4%BB%87%E8%A8%98)%%
# 1844 📚 基督山伯爵(The Count of Monte Cristo)
[[蒸发在千里之外]]