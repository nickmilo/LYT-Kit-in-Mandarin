[[+主页]]
%% - metadata:
	- 标签: #MOC %% 
# 健康 MOC
这是针对身体健康、养生、训练和运动等领域的。

[[呼吸训练 MOC]] | [[毒物兴奋效应 MOC]] | [[姿态 MOC]]

#on/health/diet
#on/health/workout
#on/health/movements
#on/health/training
#on/health/nutrition
#my/medical

### 营养学
* [[营养学 MOC]] »» [[维生素 MOC]]

### 体能训练
- [[体能训练 MOC]] - 任何与运动有关的东西，但不包括锻炼
	- [[训练 MOC]], [[201903282254]]
- [[锻炼 MOC]] - 锻炼的细节种类（而不是具体的锻炼）
- [[伤病追踪 MOC]] - 随着时间的推移，跟踪伤害和疾病的情况
- 身体异状追踪

### 医疗和健康指标
- [[医疗 MOC]] - 更多的私人和个人健康信息
	- 任何血液检查结果：空腹血糖、胆固醇、维生素 D 等。