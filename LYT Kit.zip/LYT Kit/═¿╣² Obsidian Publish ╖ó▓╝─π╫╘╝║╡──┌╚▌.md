真是不可思议，我只是在打字

然后我点击发布按钮

然后它们便已经在网上了

这又是一个......游戏规则的改变者

抱歉我过度使用了这个词，但这就是事实

你还在等什么呢？

现在就开始分享你的创作吧， [获取 Obsidian Publish](https://obsidian.md/pricing).

---

### 基于 Obsidian Publish 的数字花园
- [Andy's Notes](https://publish.obsidian.md/andymatuschak/_Start+Here) - 安迪·马图沙克(Andy Matuschak)
- [Ehsan's Notes](https://notes.thisisehsan.com/Networked+Note+Making/A+designer's+guide+to+networked+notemaking+with+Obsidian) - 埃赫桑·努尔萨莱希(Ehsan Noursalehi)
- [Moby Diction](https://publish.obsidian.md/mobydiction/_About) - 大卫·德赖斯代尔(David Drysdale)