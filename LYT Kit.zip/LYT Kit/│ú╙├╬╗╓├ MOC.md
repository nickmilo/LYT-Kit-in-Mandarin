[[+主页]]
%% - metadata:
	- 标签: #MOC %% 
# 常用位置 MOC 
欢迎来到你所收集到的有趣玩意儿的“地址簿”。试着点击 #quote/100 来看看几个结果。

注意：由于我从 LYT 工具包中删除了 quote/s 包，下面的大多数标签都不会弹出结果。

| [[了解 MOC]] | 

## 引用
| `#quote` | `#quip` | `#quote/100` | `#quote/250` | `#quote/Me` |

#### 健康
#on/Health | #on/Nutrition | #on/Diet | #on/Exercise

#### 生命 & 死亡
#on/Living | #on/Dying | #on/Legacy

#### 人脉
#on/People | #on/Leadership

#### 个人发展与美德
#on/Attitude #on/Belief #on/Courage
#on/Action #on/Doing #on/Starting
#on/Perseverance #on/Toughness
#on/Reps #on/Practice #on/Excellence #on/Luck
#on/Integrity

#### 规划和战略
#on/Goals

#### 未分类
#on/Constraints 