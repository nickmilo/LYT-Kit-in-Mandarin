# 卡珊德拉(Cassandra)
卡珊德拉在神话中突出的形象是一名不被听信的女先知。

“小心三月的厄运”与卡珊德拉有关。

盲人守护者(Blind Guardian) 的 《然后是沉默(And then there was silence)》中有关于卡珊德拉的典故。