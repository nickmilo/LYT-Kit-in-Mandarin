[[+主页]]
%% - metadata:
	- 标签: #MOC %% 
# 人物 MOC
这是一个记录值得注意的信息以纪念我生命中的重要人物的地方。

#people  | #meeting

#people/ping
#people/waiting
#people/personal/family
#people/personal/friend
#people/personal/LYT
#people/personal/ENT
#people/personal/ENT/HBO
#people/personal/NYC
#people/personal/LA

[[生日案例|生日]] | 人与人之间的联系

---
- 职业，工作，行业
	- 同业者
	- 未分类的 #on/ENT
	- HBO 申请人 
	- 行业延伸

---
#### 其他
- 历史上的著名人物

### 模板
你可能需要某些关键信息的模板，这取决于你在多大程度上会使用你的数字图书馆作为关系管理的工具。