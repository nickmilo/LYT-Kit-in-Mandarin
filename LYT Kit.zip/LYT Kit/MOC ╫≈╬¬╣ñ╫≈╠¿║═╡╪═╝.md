[[LYT 工具包]]
%% - metadata:
	- 标签: #on/PKM %%
# MOC 作为工作台和地图

---
你走进个人仓库:
![[warehouse.jpg]]

---
*准确*地记录相关笔记，并把它们放在一个新的工作台上:
![[moravian-workbench-will-myers-old-salem.jpg]]

---
你*制作*这些笔记:
![[Craft2.png]]

---
![[Craft3.png]]

---
...并创造了一些特别的东西:
![[map using.jpg]]

---
然后你把你新制作的笔记*编入*资料库的其他部分:
![[Map_Wall_blog.jpg]]