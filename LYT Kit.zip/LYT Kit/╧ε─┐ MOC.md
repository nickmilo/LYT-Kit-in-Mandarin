[[+主页]]
- metadata:
	- 标签: #MOC `#project/active` `#project/archive`
	- 关联至: [[灵感 MOC]], [[项目模板 ✂️]]

# 项目 MOC
用链接框架来管理项目和任务有绝佳的方法。然而，LYT 的观点是，大多数项目需要*更少*的维护工作而不是更多。不要对自己进行微观管理，让它保持精简。给自己一个大的方向，让自己的智慧给你带来惊喜。这就是为什么以下的项目都是刻意精简的 “封面”。

```query
tag:#project/active
```


---
```query
tag:#project/archive
```